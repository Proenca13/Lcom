//
// Created by joao on 09-04-2024.
//

#ifndef SHARED_VBE_H
#define SHARED_VBE_H

#define DIRECT_COLOR 0x06
#define VBE 0x10

#endif //SHARED_VBE_H
